-- this enables simple print statements to log to lovec console during gameplay
-- from https://love2d.org/forums/viewtopic.php?t=79579

function love.conf(t)
	t.console = true
end

